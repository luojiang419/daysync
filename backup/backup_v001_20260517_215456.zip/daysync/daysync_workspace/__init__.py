"""DaySync workspace marker package."""
