"""DaySync core tests package."""
