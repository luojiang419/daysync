"""DaySync services namespace."""
