"""DaySync workspace marker package."""
