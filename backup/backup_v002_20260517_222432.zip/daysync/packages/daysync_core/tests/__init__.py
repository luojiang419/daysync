"""DaySync core tests package."""
