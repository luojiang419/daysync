"""DaySync services namespace."""
